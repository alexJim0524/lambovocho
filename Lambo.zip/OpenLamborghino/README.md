# Linea


Importante!, Esta librería está hecha para el QTR-8A recortado a 6 sensores. 
Las 6 salidas del QTR deben ir en orden, hacia las entradas analógicas del arduino.


1 ---> A0;
2 ---> A1;
3 ---> A2;
4 ---> A3;
5 ---> A4;
6 ---> A5;


La razón del por qué Lamborghino utiliza 6 sensores en vez de 8, es porque con 6 sensores y una buena programación, es suficiente para que el robot corra muy bien.

